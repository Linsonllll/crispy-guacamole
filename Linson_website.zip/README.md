# Linson - Course Selling Website
This is a simple course-selling website with PayPal and Razorpay integration.